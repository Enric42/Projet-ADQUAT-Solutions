<?php
define('WP_CACHE', false);



/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', '');

/** MySQL database username */
define('DB_USER',       '');

/** MySQL database password */
define('DB_PASSWORD',       '');

/** MySQL hostname */
define('DB_HOST', '');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',       '%L(j(IL2XgacHI@NiygoN0mY&KVn!yuoO4Do0NbgRleHeNe44ROGjdbyYsxyXvCB');
define('SECURE_AUTH_KEY',       '2GHnMQ3OYWb^CfS3UE#q*MCU@cTa^6!wU&jnx(f7N6awzfXPv2z#39o7O7EQ@()W');
define('LOGGED_IN_KEY',       'q17ucEJYLH4h^xxuM3C23v#MH%UpiGu(z(kdooQw0FRHx9UH7DpcNQrazxBJkenj');
define('NONCE_KEY',       '6e2Xf9WV(tt9C96p^HaKqEz8Ij!ZW2qhlc&55SKufU2FmBFGAC%i!#qEIlBxOTQb');
define('AUTH_SALT',       '4EPrGDTurzq&5v2VzzhmtbpTB%4X47Z94jZ&(AVl7Nhvwg1k30LWewvO(h3SIhfp');
define('SECURE_AUTH_SALT',       '0cEt462sWxLaDPp2K*ihRGH08R6%av5@4Lyo#qq@M#EeBB!^JNQaOUEy6DKu!L9u');
define('LOGGED_IN_SALT',       'o4O5rgyO0CXlkt4KeBvXE)IzIqKl!XK4*P1a(p#sThIivaADkKDM(VcvCbF(3P@4');
define('NONCE_SALT',       'Nnx6N!7MqjXe6f1ru*f%(%vC@JpHud4c*z*nvJRObYlk(4H0VSAPioAp0i4YrIG2');
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define( 'WP_ALLOW_MULTISITE', true );

define ('FS_METHOD', 'direct');

/**Plus de mémoire PHP */
define('WP_MEMORY_LIMIT', '256M');