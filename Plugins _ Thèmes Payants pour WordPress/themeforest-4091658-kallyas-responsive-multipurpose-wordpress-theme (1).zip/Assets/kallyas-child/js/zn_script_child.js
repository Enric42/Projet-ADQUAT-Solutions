(function ($) {

    $(window).load(function () {

    	// YOUR CONTENT HERE

    });
	
})(jQuery);