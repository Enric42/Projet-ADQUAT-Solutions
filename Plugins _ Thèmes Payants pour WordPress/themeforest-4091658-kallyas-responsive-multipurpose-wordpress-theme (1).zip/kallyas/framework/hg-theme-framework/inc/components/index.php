<?php
if ( ! defined( 'ABSPATH' ) ) {
	return;
}

require 'ajax-load-more.php';
