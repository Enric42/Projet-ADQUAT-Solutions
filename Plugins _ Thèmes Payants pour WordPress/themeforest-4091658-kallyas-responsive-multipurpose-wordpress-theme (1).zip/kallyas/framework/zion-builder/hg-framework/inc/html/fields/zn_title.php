<?php

class ZnHgFw_Html_Zn_Title extends ZnHgFw_BaseFieldType{

	var $type = 'zn_title';

	function render($option) {
		return '';
	}

}
