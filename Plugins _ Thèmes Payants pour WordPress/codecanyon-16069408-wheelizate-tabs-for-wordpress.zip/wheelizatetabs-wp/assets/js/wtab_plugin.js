(function() {
    tinymce.create('tinymce.plugins.wheelizateTabs', {
        init : function(ed, url) {
            ed.addButton('wheelizatetabs', {
                title: 'Wheelizate Tabs Shortcodes',
                image : url+'/wtab_icon.png',
                onclick : function() {
                    create_wheelizate_tab_settings();
                    jQuery( "#wtabs-settingsform" ).dialog({
                        dialogClass : 'wp-dialog wtabs-dialog',
                        autoOpen: true,
                        height: 'auto',
                        width: 'auto',
                        modal: true
                    });
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
        getInfo : function() {
            return {
                longname: "Wheelizate Tabs Shortcodes",
                author: 'softwaretailoring.net',
                authorurl: 'http://softwaretailoring.net',
                infourl: 'http://wtabs.softwaretailoring.net',
                version : "1.1"
            };
        }
    });
    tinymce.PluginManager.add('wheelizatetabs', tinymce.plugins.wheelizateTabs);
})();

function wtabs_tabtype_set() {
    if (jQuery('#wtabs-tabtype').val() == 'Center' ||
        jQuery('#wtabs-tabtype').val() == 'Apart') {
        jQuery('#wtabs-tabsubtype-topleft').hide();
        jQuery('#wtabs-tabsubtype-topright').hide();
        jQuery('#wtabs-tabsubtype-bottomright').hide();
        jQuery('#wtabs-tabsubtype-bottomleft').hide();
        jQuery('#wtabs-tabsubtype-top').show();
        jQuery('#wtabs-tabsubtype-right').show();
        jQuery('#wtabs-tabsubtype-bottom').show();
        jQuery('#wtabs-tabsubtype-left').show();
        jQuery('#wtabs-tabsubtype-top').attr('selected', 'selected');
    } else {
        jQuery('#wtabs-tabsubtype-topleft').show();
        jQuery('#wtabs-tabsubtype-topright').show();
        jQuery('#wtabs-tabsubtype-bottomright').show();
        jQuery('#wtabs-tabsubtype-bottomleft').show();
        jQuery('#wtabs-tabsubtype-top').hide();
        jQuery('#wtabs-tabsubtype-right').hide();
        jQuery('#wtabs-tabsubtype-bottom').hide();
        jQuery('#wtabs-tabsubtype-left').hide();
        jQuery('#wtabs-tabsubtype-topleft').attr('selected', 'selected');
    }
}

function wtabs_themetype_set() {
    if (jQuery('#wtabs-themetype').val() == 'Custom') {
        jQuery('#wtabs-themefile-label').show();
        jQuery('#wtabs-themefile').show();
        jQuery('#wtabs-themecolor-label').hide();
        jQuery('#wtabs-themecolor').hide();
    } else {
        jQuery('#wtabs-themecolor-label').show();
        jQuery('#wtabs-themecolor').show();
        jQuery('#wtabs-themefile-label').hide();
        jQuery('#wtabs-themefile').hide();
    }
}

function wtabs_selectedtab_set() {
    var tabcount = jQuery('#wtabs-tabnumber').val();
    jQuery('#wtabs-selectedtab-1').attr('selected', 'selected');
    jQuery('#wtabs-selectedtab-2').hide();
    jQuery('#wtabs-selectedtab-3').hide();
    jQuery('#wtabs-selectedtab-4').hide();
    jQuery('#wtabs-selectedtab-5').hide();
    jQuery('#wtabs-selectedtab-6').hide();
    jQuery('#wtabs-selectedtab-7').hide();
    jQuery('#wtabs-selectedtab-8').hide();

    for (var i = 2; i <= tabcount; i++) {
        jQuery('#wtabs-selectedtab-'+i.toString()).show();
    }
}

function wtabs_titlesize_set() {
    if (jQuery('#wtabs-tabtitle').val() != 'text') {
        jQuery('#wtabs-titlesize-label').prop("disabled", false);
        jQuery('#wtabs-titlesize').prop("disabled", false);
    } else {
        jQuery('#wtabs-titlesize-label').prop("disabled", true);
        jQuery('#wtabs-titlesize').prop("disabled", true);
    }
}

function create_wheelizate_tab_settings() {
    if(jQuery('#wtabs-settingsform').length){
        jQuery('#wtabs-settingsform').remove();
    }
    
    var form = jQuery('<div id="wtabs-settingsform" title="Wheelizate Tabs Settings">\
                <h1>Tabs</h1>\
                <table class="form-table" style="margin-top: 0px;">\
			    <tr>\
				    <th><label for="wtabs-tabnumber">Number of tabs</label></th>\
				    <td><select name="tabnumber" id="wtabs-tabnumber">\
					    <option value="2">2</option>\
					    <option value="3">3</option>\
                        <option value="4" selected="selected">4</option>\
                        <option value="5">5</option>\
                        <option value="6">6</option>\
                        <option value="7">7</option>\
                        <option value="8">8</option>\
				    </select><br />\
                    </td>\
				    <th><label for="wtabs-selectedtab">Selected tab</label></th>\
				    <td><select name="selectedtab" id="wtabs-selectedtab">\
                        <option id="wtabs-selectedtab-1" value="0" selected="selected">1</option>\
					    <option id="wtabs-selectedtab-2" value="1">2</option>\
					    <option id="wtabs-selectedtab-3" value="2">3</option>\
                        <option id="wtabs-selectedtab-4" value="3">4</option>\
                        <option id="wtabs-selectedtab-5" value="4">5</option>\
                        <option id="wtabs-selectedtab-6" value="5">6</option>\
                        <option id="wtabs-selectedtab-7" value="6">7</option>\
                        <option id="wtabs-selectedtab-8" value="7">8</option>\
				    </select><br />\
                    </td>\
			    </tr>\
			    <tr>\
				    <th><label for="wtabs-tabtype">Tab\'s type</label></th>\
				    <td><select name="type" id="wtabs-tabtype">\
					    <option value="Corner" selected="selected">Corner</option>\
					    <option value="Side">Side</option>\
                        <option value="Classic">Classic</option>\
                        <option value="Center">Center</option>\
                        <option value="Apart">Apart</option>\
				    </select><br />\
				    </td>\
				    <th><label for="wtabs-tabsubtype">Tab\'s subtype</label></th>\
				    <td><select name="subtype" id="wtabs-tabsubtype">\
					    <option id="wtabs-tabsubtype-topleft" value="TopLeft" selected="selected">Top-left</option>\
					    <option id="wtabs-tabsubtype-topright" value="TopRight">Top-right</option>\
                        <option id="wtabs-tabsubtype-bottomright" value="BottomRight">Bottom-right</option>\
                        <option id="wtabs-tabsubtype-bottomleft" value="BottomLeft">Bottom-left</option>\
					    <option id="wtabs-tabsubtype-top" value="Top">Top</option>\
					    <option id="wtabs-tabsubtype-right" value="Right">Right</option>\
                        <option id="wtabs-tabsubtype-bottom" value="Bottom">Bottom</option>\
                        <option id="wtabs-tabsubtype-left" value="Left">Left</option>\
				    </select><br />\
				    </td>\
			    </tr>\
			    <tr>\
				    <th><label for="wtabs-themetype">Theme\'s type</label></th>\
				    <td><select name="themetype" id="wtabs-themetype">\
					    <option value="Basic">Basic</option>\
					    <option value="Select">Select</option>\
                        <option value="Solid">Solid</option>\
                        <option value="Color" selected="selected">Color</option>\
                        <option value="Inverse">Inverse</option>\
                        <option value="Border">Border</option>\
                        <option value="Custom">Custom</option>\
				    </select><br />\
				    </td>\
                    <div id="tabs-themetype-default">\
				        <th>\
                            <label for="wtabs-themecolor" id="wtabs-themecolor-label">Theme\'s color</label>\
                            <label for="wtabs-themefile" id="wtabs-themefile-label">Theme\'s file</label>\
                        </th>\
				        <td><select name="themecolor" id="wtabs-themecolor">\
					        <option value="Blue" selected="selected">Blue</option>\
					        <option value="Green">Green</option>\
                            <option value="Red">Red</option>\
                            <option value="Brown">Brown</option>\
                            <option value="Yellow">Yellow</option>\
                            <option value="Gray">Gray</option>\
				        </select>\
				        <input type="text" name="themefile" id="wtabs-themefile" />\
				        </td>\
                    </div>\
			    </tr>\
		    </table>\
            <h1>Wheel</h1>\
            <table class="form-table" style="margin-top: 0px;">\
			<tr>\
				<th><label for="wtabs-wheeltype">Wheel\'s type</label></th>\
				<td><select name="wheeltype" id="wtabs-wheeltype">\
					<option value="Pie" selected="selected">Pie</option>\
					<option value="Donut">Donut</option>\
					<option value="Flower">Flower</option>\
					<option value="Icon">Icon</option>\
					<option value="Cog">Cog</option>\
					<option value="Wheel">Wheel</option>\
				</select><br />\
				</td>\
				<th><label for="wtabs-wheelradius">Wheel\'s radius</label></th>\
				<td><input type="number" name="wheelradius" id="wtabs-wheelradius" min="20" value="100"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="wtabs-marker">Show marker</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-marker">\
                    <small>Check this checkbox to enable marker</small>\
				</td>\
                <th><label for="wtabs-clockwise">Clockwise</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-clockwise">\
                    <small>Check this checkbox to clockwise order</small>\
				</td>\
			</tr>\
            <tr>\
                <th><label for="wtabs-wheelanimation">Wheel\'s animation</label></th>\
				<td><select name="wheelanimation" id="wtabs-wheelanimation">\
					<option value="linear" selected="selected">linear</option>\
					<option value="easeInOut">easeInOut</option>\
                    <option value="easeIn">easeIn</option>\
                    <option value="easeOut">easeOut</option>\
                    <option value="backIn">backIn</option>\
                    <option value="backOut">backOut</option>\
                    <option value="elastic">elastic</option>\
                    <option value="bounce">bounce</option>\
				</select><br />\
				</td>\
				<th><label for="wtabs-sliderseconds">Slider\'s seconds</label></th>\
				<td><input type="number" name="sliderseconds" id="wtabs-sliderseconds" value="0" min="0" />&nbsp;&nbsp;Sets the seconds of slider mode.</td>\
            </tr>\
            </table>\
            <h1>Title</h1>\
            <table class="form-table" style="margin-top: 0px;">\
            <tr>\
                <th><label for="wtabs-tabtitle">Tab\'s title type</label></th>\
				<td><select name="tabtitle" id="wtabs-tabtitle">\
					<option value="text" selected="selected">text</option>\
					<option value="icon">icon (built-in SVG icons)</option>\
                    <option value="image">image (.png .jpg .gif .svg files)</option>\
				</select><br />\
                </td>\
                <th><label for="wtabs-titlesize" id="wtabs-titlesize-label">Tab\'s title size</label></th>\
				<td><input type="number" name="titlesize" id="wtabs-titlesize" value="30" min="5"/>&nbsp;&nbsp;Sets the size of icon/image.\
                &nbsp;&nbsp;<a href="http://wtabs.softwaretailoring.net/icons.html" target="_blank">Icons</a>\
                </td>\
			</tr>\
			<tr>\
                <th><label for="wtabs-titlerotateangle">Title rotation</label></th>\
				<td><input type="number" name="titlerotateangle" id="wtabs-titlerotateangle" value="null"/>&nbsp;&nbsp;Sets the angle of titles.</td>\
				<th><label for="wtabs-tooltip">Tooltips</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-tooltip">\
                    <small>Check this checkbox to show tooltips</small>\
				</td>\
			</tr>\
            </table>\
            <h1>Tab pane</h1>\
            <table class="form-table" style="margin-top: 0px;">\
			<tr>\
				<th><label for="wtabs-tabrounded">Rounded corners</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-tabrounded">\
                    <small>Check this checkbox to rounded panes</small>\
				</td>\
                <th><label for="wtabs-tabshadowed">Shadow</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-tabshadowed">\
                    <small>Check this checkbox to shadowed panes</small>\
				</td>\
			</tr>\
			<tr>\
				<th><label for="wtabs-paneanimation">Pane\'s animation</label></th>\
				<td><select name="paneanimation" id="wtabs-paneanimation">\
					<option value="null" selected="selected">none</option>\
					<option value="fade">fade</option>\
                    <option value="slide">slide</option>\
                    <option value="bounce">bounce</option>\
                    <option value="rotate">rotate</option>\
				</select><br />\
				</td>\
                <th><label for="wtabs-minheight">Tab pane\'s height</label></th>\
				<td><input type="number" name="minheight" id="wtabs-minheight" value="null" min="100"/>&nbsp;&nbsp;Sets the minimum height of tab pane.</td>\
			</tr>\
            </table>\
            <h1>Keyboard</h1>\
            <table class="form-table" style="margin-top: 0px;">\
			<tr>\
				<th><label for="wtabs-keyenabled">Enable</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-keyenabled">\
                    <small>Check this checkbox to enable keyboard</small>\
                    &nbsp;&nbsp;<a href="http://keycode.info/" target="_blank">Keycodes</a>\
				</td>\
				<th><label for="wtabs-keyonfocus">Only focus</label></th>\
				<td>\
				    <input type="checkbox" id="wtabs-keyonfocus">\
                    <small>Check this checkbox to focus required</small>\
				</td>\
			</tr>\
            <tr>\
                <th><label for="wtabs-keynext">Next key &#9205;</label></th>\
				<td><input type="number" name="titlesize" id="wtabs-keynext" value="39"/>&nbsp;&nbsp;Sets the keycode of next key.\
                </td>\
                <th><label for="wtabs-keynext2">Next key 2  &#9206;</label></th>\
				<td><input type="number" name="titlesize" id="wtabs-keynext2" value="38"/>&nbsp;&nbsp;Alternative keycode of next key.\
                </td>\
			</tr>\
            <tr>\
                <th><label for="wtabs-keyprev">Previous key &#9204;</label></th>\
				<td><input type="number" name="titlesize" id="wtabs-keyprev" value="37"/>&nbsp;&nbsp;Sets the keycode of previous key.\
                </td>\
                <th><label for="wtabs-keyprev2">Previous key 2  &#9207;</label></th>\
				<td><input type="number" name="titlesize" id="wtabs-keyprev2" value="40"/>&nbsp;&nbsp;Alternative keycode of previous key.\
                </td>\
			</tr>\
            </table>\
		<p class="submit" style="padding-right: 10px;text-align: right;">\
            <input type="button" id="wtabs-cancel" class="button-default" value="Cancel" name="cancel" />&nbsp;\
			<input type="button" id="wtabs-submit" class="button-primary" value="Insert Wheelizate Tab" name="submit" />\
		</p>\
        <a href="http://wtabs.softwaretailoring.net/documentation.wp.html" target="_blank">Documentation</a>\
		</div>');

    var table = form.find('table');
    form.appendTo('body').hide();

    wtabs_tabtype_set();
    wtabs_themetype_set();
    wtabs_selectedtab_set();
    wtabs_titlesize_set();
    jQuery('#wtabs-tabtype').change(function () {
        wtabs_tabtype_set();
    });
    jQuery('#wtabs-themetype').change(function () {
        wtabs_themetype_set();
    });
    jQuery('#wtabs-tabnumber').change(function () {
        wtabs_selectedtab_set();
    });
    jQuery('#wtabs-tabtitle').change(function () {
        wtabs_titlesize_set();
    });

    form.find('#wtabs-submit').click(function () {

        var tabattrs='',tabpanes= 0;
        
        if (table.find('#wtabs-selectedtab').val() > 0) {
            tabattrs = ' selectedtab="' + table.find('#wtabs-selectedtab').val() + '"';
        }

        if (table.find('#wtabs-tabtype').val()!='') {
            tabattrs += ' tabtype="' + table.find('#wtabs-tabtype').val() + '"';
        }

        if (table.find('#wtabs-tabsubtype').val() != '') {
            tabattrs += ' tabsubtype="' + table.find('#wtabs-tabsubtype').val() + '"';
        }

        if (table.find('#wtabs-themetype').val() != '') {
            tabattrs += ' tabthemetype="' + table.find('#wtabs-themetype').val() + '"';
        }

        if (table.find('#wtabs-themetype').val() != 'Custom') {
            tabattrs += ' themefile="theme' + table.find('#wtabs-themetype').val() + '/' + table.find('#wtabs-themecolor').val() + '/theme.min.css"';
        }
        else {
            var themefilename = 'mytheme.css';
            if (table.find('#wtabs-themefile').val() != '') {
                themefilename = table.find('#wtabs-themefile').val();
            }

            tabattrs += ' themefile="theme' + table.find('#wtabs-themetype').val() + '/' + themefilename + '"';
        }

        if (table.find('#wtabs-wheeltype').val() != '') {
            tabattrs += ' tabwheeltype="' + table.find('#wtabs-wheeltype').val() + '"';
        }
        
        var wheelradius = table.find('#wtabs-wheelradius').val();
        if (Math.floor(wheelradius) == wheelradius && jQuery.isNumeric(wheelradius)) {
            tabattrs += ' wheelradius="' + wheelradius + '"';
        } else {
            tabattrs += ' wheelradius="100"';
        }

        if (jQuery('#wtabs-marker').prop('checked')) {
            tabattrs += ' marker="true"';
        }

        if (jQuery('#wtabs-clockwise').prop('checked')) {
            tabattrs += ' clockwise="true"';
        }

        if (jQuery('#wtabs-tabrounded').prop('checked')) {
            tabattrs += ' tabrounded="true"';
        }

        if (jQuery('#wtabs-tabshadowed').prop('checked')) {
            tabattrs += ' tabshadowed="true"';
        }

        if (table.find('#wtabs-wheelanimation').val() != '') {
            tabattrs += ' wheelanimation="' + table.find('#wtabs-wheelanimation').val() + '"';
        }

        if (table.find('#wtabs-paneanimation').val() != '') {
            tabattrs += ' paneanimation="' + table.find('#wtabs-paneanimation').val() + '"';
        }

        if (jQuery('#wtabs-keyenabled').prop('checked')) {
            tabattrs += ' keyenabled="true"';
        }

        if (jQuery('#wtabs-keyonfocus').prop('checked')) {
            tabattrs += ' keyonfocus="true"';
        }

        if (table.find('#wtabs-keynext').val() != '39') {
            tabattrs += ' keynext="' + table.find('#wtabs-keynext').val() + '"';
        }

        if (table.find('#wtabs-keynext2').val() != '38') {
            tabattrs += ' keynext2="' + table.find('#wtabs-keynext2').val() + '"';
        }

        if (table.find('#wtabs-keyprev').val() != '37') {
            tabattrs += ' keyprev="' + table.find('#wtabs-keyprev').val() + '"';
        }

        if (table.find('#wtabs-keyprev2').val() != '40') {
            tabattrs += ' keyprev2="' + table.find('#wtabs-keyprev2').val() + '"';
        }

        if (table.find('#wtabs-tabtitle').val() != 'text') {
            var titlesize = table.find('#wtabs-titlesize').val();
            if (Math.floor(titlesize) == titlesize && jQuery.isNumeric(titlesize)) {
                tabattrs += ' iconheight="' + titlesize + '" iconwidth="' + titlesize + '"';
            }
        }

        var titlerotateangle = table.find('#wtabs-titlerotateangle').val();
        if (Math.floor(titlerotateangle) == titlerotateangle && jQuery.isNumeric(titlerotateangle)) {
            tabattrs += ' titlerotateangle="' + titlerotateangle + '"';
        }

        var minheight = table.find('#wtabs-minheight').val();
        if (Math.floor(minheight) == minheight && jQuery.isNumeric(minheight)) {
            if (minheight < 100) { minheight = 100; }
            tabattrs += ' minheight="' + minheight + '"';
        }

        var sliderSeconds = table.find('#wtabs-sliderseconds').val();
        if (Math.floor(sliderSeconds) == sliderSeconds && jQuery.isNumeric(sliderSeconds)) {
            if (sliderSeconds > 0) {
                tabattrs += ' sliderseconds="' + sliderSeconds + '"';
            }
        }

        var tabpanes = table.find('#wtabs-tabnumber').val();
        var tabtitletype = table.find('#wtabs-tabtitle').val();
        var istooltips = false;
        if (jQuery('#wtabs-tooltip').prop('checked')) {
            istooltips = true;
        }

        var shortcode = '[wtab' + tabattrs + ']';

        for (var i = 1; i <= tabpanes; i++) {
            shortcode += '<br/>[wtabtitle ';
            if (tabtitletype == "text") {
                shortcode += 'text="' + i + '"';
            }
            else if (tabtitletype == "icon") {
                shortcode += 'icon="wrench"';
            }
            else if (tabtitletype == "image") {
                shortcode += 'image="http://wtabswp.softwaretailoring.net/wp-content/plugins/wheelizatetabs-wp/assets/js/wtab_icon.png"';
            }
            if (istooltips) {
                shortcode += ' tooltip="Tooltip ' + i + '"';
            }
            shortcode += ']Tab pane ' + i + '[/wtabtitle]';
        }

        shortcode += '<br/>[/wtab]';

        // inserts the shortcode into the active editor
        tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);

        // closes dialog box
        jQuery( "#wtabs-settingsform" ).dialog('close');

    });

    form.find('#wtabs-cancel').click(function () {
        // closes dialog box
        jQuery("#wtabs-settingsform").dialog('close');
    });
}


