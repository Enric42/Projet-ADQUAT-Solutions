=== Wheelizate Tabs ===
Contributors: softwaretailoring
Link: http://softwaretailoring.net
Tags: Wordpress Tab Shortcodes, Responsive Tabs, Editor plugin, TinyMCE
Requires at least: 3.0
Tested up to: 4.6.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://codecanyon.net/licenses/standard

Wheelizate Tabs is an alternative solution for tabbed navigation. It uses a wheel instead of horizontal or vertical buttons.

== Description ==
>For plugin support go to [http://softwaretailoring.net](http://softwaretailoring.net)

>Wordpress 4.0 ready

* visual tinyMCE editor button
* easy to configure CSS

[Wheelizate Tabs Demo](http://wtabswp.softwaretailoring.net)

Follow me [@Twitter](https://twitter.com/@sftwr_tlrng)

== Installation with zip ==

1.Upload:
In the admin panel, find Plugins->Add New, click it, click 'Upload Plugin' button.

2.Install:
Click Open File button, find wheelizatetabs-wp.zip in your hard drive, open it and press 'Install Now'.

3.Activate:
You will see: 'Plugin installed successfully.', press 'Activate Plugin'

== Installation via FTP ==

1.Upload:
Unzip wheelizatetabs-wp.zip file, and upload all files to your WordPress folder: <root>/wp-content/plugins/wheelizatetabs-wp

2.Activate:
In the admin panel, find Plugins->Installed Plugins, click it, activate Wheelizate Tabs.


Now you can see a new button in the TinyMCE Editor in post and pages, use this buttons to create Wheelizate Tabs in pages/posts content.


== Changelog ==

= 1.1 =

* [Added] New feature: keyboard handling

= 1.0 =

* [Added] Initial release.
