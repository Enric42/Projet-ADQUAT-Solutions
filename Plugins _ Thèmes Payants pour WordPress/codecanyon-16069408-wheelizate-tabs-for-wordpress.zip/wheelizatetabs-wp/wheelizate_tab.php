<?php
/*
  Plugin Name: Wheelizate Tabs
  Plugin URI: http://wtabswp.softwaretailoring.net
  Description: An alternative solution for tabbed navigation. It uses a wheel instead of horizontal or vertical buttons.
  Version: 1.1
  Author: softwaretailoring.net
  Author URI: http://softwaretailoring.net
  License: http://codecanyon.net/licenses/standard
 */
define('WTAB_VERSION', '1.1');
define('WTAB_BASE_URL', plugins_url('',__FILE__));
define('WTAB_ASSETS_URL', WTAB_BASE_URL . '/assets/');

$_wtabs=array('current_id'=>0);
class wheelizateTabs {

    function __construct(){
        $pluginmenu=explode('/',plugin_basename(__FILE__));
        $this->plugin_name=$pluginmenu[0];

        add_action('init',array($this,'wtab_shortcode'));

        add_action('admin_enqueue_scripts', array($this, 'wtab_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'wtab_enqueue_scripts'),-10);
        add_action('wp_enqueue_scripts', array($this, 'wtab_dynamic_scripts'),100);

        add_shortcode('wtab', array($this,'set_wtab_div'));
        add_shortcode('wtabtitle', array($this,'set_wtab_title'));
    }

    public function wtab_shortcode(){
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages'))
            return;

        if (get_user_option('rich_editing') == 'true') {
            add_filter("mce_external_plugins", array( $this,"add_wtabs_plugin"));
        }
    }

    public function register_wtabs_button($buttons) {
        $buttons[]='wheelizatetabs';
        return $buttons;
    }

    public function add_wtabs_plugin($plugin_array) {
        add_filter('mce_buttons', array( $this,'register_wtabs_button'),903.498);
        $plugin_array['wheelizatetabs']=plugins_url('/assets/js/wtab_plugin.min.js', __FILE__);
        return $plugin_array;
    }

    public function set_wtab_div($params, $content = null) {
        global $_wtabs, $shortcode_tags;
        if (!count($_wtabs)) {
            $_wtabs = array('current_id'=>0);
        }
        global $post;
        $slug = get_post( $post )->post_name;

        extract(shortcode_atts(array(
            'ids'=>count($_wtabs),
            'id' => count($_wtabs).'-'.$slug.'-'.rand(11111,99999),
            'selectedtab' => '',
            'tabtype' =>'',
            'tabsubtype'=>'',
            'tabthemetype'=>'',
			'themefile'=>'',
            'tabwheeltype'=>'',
            'titlerotateangle'=>'',
            'iconheight'=>'',
            'iconwidth'=>'',
            'wheelradius'=>'',
            'clockwise'=>'',
            'marker'=>'',
            'wheelanimation'=>'',
			'paneanimation'=>'',
			'tabrounded'=>'',
			'tabshadowed'=>'',
            'minheight'=>'',
			'sliderseconds'=>'',
			'keyenabled'=>'',
			'keyonfocus'=>'',
			'keyprev'=>'',
			'keyprev2'=>'',
			'keynext'=>'',
			'keynext2'=>''
        ), $params));

        $_wtabs[$ids] = array();
        $_wtabs['current_id'] = count($_wtabs)-1;

		do_shortcode($content);

		$tabattributes = "data-wtab ";

		if (trim($selectedtab) != "") {
			$tabattributes .= 'data-wtab-selectedtab="' . $selectedtab . '" ';
		}
		if (trim($tabtype) != "") {
			$tabattributes .= 'data-wtab-type="' . $tabtype . '" ';
		}
		if (trim($tabsubtype) != "") {
			$tabattributes .= 'data-wtab-subtype="' . $tabsubtype . '" ';
		}
		if (trim($tabthemetype) != "") {
			$tabattributes .= 'data-wtab-themetype="' . $tabthemetype . '" ';
		}
		if (trim($tabwheeltype) != "") {
			$tabattributes .= 'data-wtab-wheeltype="' . $tabwheeltype . '" ';
		}
		if (trim($titlerotateangle) != "") {
			$tabattributes .= 'data-wtab-titlerotateangle="' . $titlerotateangle . '" ';
		}
		if (trim($iconheight) != "") {
			$tabattributes .= 'data-wtab-iconheight="' . $iconheight . '" ';
		}
		if (trim($iconwidth) != "") {
			$tabattributes .= 'data-wtab-iconwidth="' . $iconwidth . '" ';
		}
		if (trim($wheelradius) != "") {
			$tabattributes .= 'data-wtab-wheelradius="' . $wheelradius . '" ';
		}
		if (trim($clockwise) != "") {
			$tabattributes .= 'data-wtab-clockwise ';
		}
		if (trim($marker) != "") {
			$tabattributes .= 'data-wtab-marker ';
		}
		if (trim($wheelanimation) != "") {
			$tabattributes .= 'data-wtab-wheelanimation="' . $wheelanimation . '" ';
		}
		if (trim($paneanimation) != "") {
			$tabattributes .= 'data-wtab-paneanimation="' . $paneanimation . '" ';
		}
		if (trim($tabrounded) != "") {
			$tabattributes .= 'data-wtab-tabrounded ';
		}
		if (trim($tabshadowed) != "") {
			$tabattributes .= 'data-wtab-tabshadowed ';
		}
		if (trim($minheight) != "") {
			$tabattributes .= 'data-wtab-minheight="' . $minheight . '" ';
		}
		if (trim($sliderseconds) != "") {
			$tabattributes .= 'data-wtab-sliderseconds="' . $sliderseconds . '" ';
		}
		if (trim($keyenabled) != "") {
			$tabattributes .= 'data-wtab-keyenabled ';
		}
		if (trim($keyonfocus) != "") {
			$tabattributes .= 'data-wtab-keyonfocus ';
		}
		if (trim($keyprev) != "") {
			$tabattributes .= 'data-wtab-keyprev="' . $keyprev . '" ';
		}
		if (trim($keyprev2) != "") {
			$tabattributes .= 'data-wtab-keyprev2="' . $keyprev2 . '" ';
		}
		if (trim($keynext) != "") {
			$tabattributes .= 'data-wtab-keynext="' . $keynext . '" ';
		}
		if (trim($keynext2) != "") {
			$tabattributes .= 'data-wtab-keynext2="' . $keynext2 . '" ';
		}

		if (trim($themefile) == "") {
			$themefile = 'themeColor/Blue/theme.min.css';
		}

        $output = '<div id="wtab' . $_wtabs['current_id'] . '" ' . $tabattributes . '><div>' . implode('', $_wtabs[$ids]['tabs']) . '</div>';
        $output .= '</div><script>document.addEventListener("DOMContentLoaded", function (event) { jQuery("#wtab' . $_wtabs['current_id'] . '").wheelizateTabHtml(); });';
        
		$output .= 'jQuery.get("'.plugins_url().'/wheelizatetabs-wp/assets/themes/'.$themefile.'", function (data) {';

        $output .= '    var reTab = /#tab>/gi;';
		$output .= '    var modifiedtab = data.replace(reTab, "#wtab'.$_wtabs['current_id'].'>");';

		$output .= '    var reWheel = /wheelnav-tab-wheel-/gi;';
		$output .= '    var modified = modifiedtab.replace(reWheel, "wheelnav-wtab'.$_wtabs['current_id'].'-wheel-");';

		$output .= '    var styleElement = document.createElement("style");';
        $output .= '    styleElement.setAttribute("id", "wtab'.$_wtabs['current_id'].'style");';
        $output .= '    styleElement.innerHTML = modified;';
        $output .= '    var headElement = document.getElementsByTagName("head")[0];';
        $output .= '    headElement.appendChild(styleElement);';

        $output .= '});';
		$output .= '</script>';

        $_wtabs['current_id'] = $_wtabs['current_id']-1;

        return $output;
    }

    public function set_wtab_title($params, $content = null) {
        global $_wtabs;
        extract(shortcode_atts(array(
            'text' => 'title',
			'icon' => '',
			'image' => '',
            'tooltip' => '',
        ), $params));

        $index = $_wtabs['current_id'];

        if (!isset($_wtabs[$index]['tabs'])) {
            $_wtabs[$index]['tabs'] = array();
        }

		$tabpaneattributes = 'class="wtab-pane" ';

		if (trim($tooltip) != "") {
			$tabpaneattributes .= 'data-wtab-tabtooltip="' . $tooltip . '" ';
		}

		$tabpaneattributes .= '>' . do_shortcode (trim($content)) . '</div>';

		if (trim($icon) != "") {
			$_wtabs[$index]['tabs'][] = '<div data-wtab-tabtitle-icon="' . $icon . '" ' . $tabpaneattributes;
		}
		else if (trim($image) != "") {
			$_wtabs[$index]['tabs'][] = '<div data-wtab-tabtitle-img="' . $image . '" ' . $tabpaneattributes;
		}
		else {
			$_wtabs[$index]['tabs'][] = '<div data-wtab-tabtitle-text="' . $text . '" ' . $tabpaneattributes;
		}
    }

    public function wtab_enqueue_scripts(){
        wp_enqueue_script('jquery');
		wp_enqueue_style('wtab_tab_css',WTAB_ASSETS_URL.'css/wheelizate.tab.min.css');
    }

    public function wtab_dynamic_scripts(){
		wp_enqueue_script('raphael_min',WTAB_ASSETS_URL.'js/raphael.min.js',array('jquery'),WTAB_VERSION,true);
		wp_enqueue_script('raphael_icons_min',WTAB_ASSETS_URL.'js/raphael.icons.min.js',array('raphael_min'),WTAB_VERSION,true);
		wp_enqueue_script('wheelnav_min',WTAB_ASSETS_URL.'js/wheelnav.min.js',array('raphael_min'),WTAB_VERSION,true);
		wp_enqueue_script('wheelizate_tab_min',WTAB_ASSETS_URL.'js/wheelizate.tab.min.js',array('wheelnav_min'),WTAB_VERSION,true);
    }

    public function wtab_admin_scripts(){
        global $pagenow;
        if ('post-new.php' == $pagenow || 'post.php' == $pagenow) {
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-ui-dialog');
            wp_enqueue_style ('wp-jquery-ui-dialog');
            wp_enqueue_style('wtab_admin', WTAB_ASSETS_URL.'css/wtab_admin.min.css');
        }
    }
}

function wtab_init_session () {
    if (!session_id()) {
        @session_start();
    }
}

add_action('init', 'wtab_init_session', 1);

$wtabs= new wheelizateTabs();

